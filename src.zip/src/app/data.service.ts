import { Injectable, isDevMode } from '@angular/core';
import { Observable, throwError, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

import { HttpClient, HttpErrorResponse } from '@angular/common/http';

import { QRC_Record } from './qrc-record';

@Injectable({
  providedIn: 'root'
})

export class DataService {

  newRecordForm: any;
  recordMultiplier = 472 ; // I use an id multiplier to help mask the id of the record and protect from hacking
  baseURL: string;
  userRecords: QRC_Record[];
  recordCount: number;
  defaultBackgroundName = "bg01";

  message_ErrorFetchingUserRecords = "Error fetching user records : ";
  message_BaseURLNotDefined = "Base URL is not defined";

  constructor( private http: HttpClient ) { 
    if ( isDevMode() ) {
      this.baseURL = 'http://localhost:8080/wordpress/api/';
    } else {
      this.baseURL = 'https://qrc.ninja/api/';
    }
  }

getDataLength() : number {

  console.log("Getting data length");
  return this.recordCount;

}

saveNewRecordForm

getRecordById( id: number ) : QRC_Record {

  return this.userRecords.find(function(element) {
    return element.id == id; });

}

addRecord ( QRC_Record : QRC_Record ) : QRC_Record[] {

  QRC_Record.dateCreated = JSON.stringify( new Date()) ;
  QRC_Record.validUntil = JSON.stringify( this.determineRecordDuration() );
  QRC_Record.backgroundName = this.defaultBackgroundName;

  if ( QRC_Record.shortNameUsed ) {
    QRC_Record.shortName = this.generateShortName();
  } else {
    QRC_Record.shortName = "";
  }

  this.userRecords.push( QRC_Record );

  this.createUserRecord( QRC_Record )
  .subscribe( record => { }  );

  return this.userRecords;

}

createUserRecord( record: QRC_Record ): Observable<QRC_Record> {
if (!!this.baseURL ) {
  return this.http.post(`${this.baseURL}store.php`, {data: record })
    .pipe( map((res) => {
      let errorFound = res['error'];
      if ( errorFound ) {
        console.log(this.message_ErrorFetchingUserRecords + errorFound);
        return errorFound;  
      } else {
        return record; 
      }
    }),
    catchError( this.handleError )
  );
} else {
  console.log(this.message_BaseURLNotDefined);
}
}
//
// For now, we will give records a one year validity
//
determineRecordDuration() : Date {

  let today = new Date();

  return new Date( today.getFullYear() + 1, today.getMonth(), today.getDay() );
}

generateShortName() : string {

  return "hi!";

}
  //
  // We want to ensure that we support unicode and at the same time make sure that we don't have any exposer to
  // SQL Injection.  To accomplish this, strings will be converted to unicode strings.
  //
convertUnicodeToString( text: string ): string {

  let newText =  text.replace(/\\u[\dA-F]{4}/gi, 
    function (match) {
         return String.fromCharCode(parseInt(match.replace(/\\u/g, ''), 16));
    });
    
  return newText;

}

convertStringToUnicode( text: string ) : string {

  var newText = "";
  for(var i = 0; i < text.length; i++){
      // Assumption: all characters are < 0xffff
      newText += "\\u" + ("000" + text[i].charCodeAt(0).toString(16)).substr(-4);
  }

  return newText;

}

deleteSQLRecord( id: number ) : Observable<QRC_Record>  {

  let deletedRecord = this.getRecordById( id );

  if (!!this.baseURL ) {
    return this.http.get(`${this.baseURL}zigzagzip.php?ipsilip=ipsiloop&rtfu=` + ( deletedRecord.id * this.recordMultiplier ) ).pipe(
      map((res) => {
        if ( !!res ) {
          let errorFound = res['error'];
          if ( errorFound ) {
            console.log(this.message_ErrorFetchingUserRecords + errorFound);
            return errorFound;  
          }
         } else {
          return of( deletedRecord ); 
        }
      }),
      catchError( this.handleError )
    );
  } else {
    console.log(this.message_BaseURLNotDefined);
  }

  return of(deletedRecord);

}

deleteRecord( id : number ) {
  //
  // First, delete the record from the SQL database, then locally
  //
  this.deleteSQLRecord( id ).subscribe ( res => {
    this.userRecords = this.userRecords.filter( record => {
        return record.id != id;
    });
  });

}

updateRecord( id: number, record: QRC_Record ) : void {
 

}

getUserRecords( userID: number ): Observable<QRC_Record[]> {
    //
  if (!!this.baseURL ) {
    return this.http.get(`${this.baseURL}getUserRecords.php?user=`+userID).pipe(
      map((res) => {
        let errorFound = res['error'];
        if ( errorFound ) {
          console.log(this.message_ErrorFetchingUserRecords + errorFound);
          return errorFound;  
        } else {
//          this.currencyTransactionWindows = res['data'];
//          return this.currencyTransactionWindows;  
            this.userRecords = res['data'];
            this.recordCount = this.userRecords.length;
            console.log(" Record count : " + this.userRecords.length);
          return res['data']; 
        }
      }),
      catchError( this.handleError )
    );
  } else {
    console.log(this.message_BaseURLNotDefined);
  }
}

private handleError(error: HttpErrorResponse) {
  console.log(error);
  // return an observable with a user friendly message
  return throwError('HTTP Error! ' + error.message );
}

}
