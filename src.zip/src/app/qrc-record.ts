
export interface QRC_Record {
    id: number,                 // Doesn't everything have an ID?
    userID: number,             // The username has bad characters for the SQL search, so let's just have an id
    displayName: string,         // So the user can identify the QR Code
    urlString: string,          // the QR Code will decode to this value
    shortNameUsed: boolean,     // Is a shortname to be used?
    shortName: string,          // If the QR Code is a shortname
    backgroundName: string,     // Name of the background
    callToActionString: string, // Call To Action
    dateCreated: string,
    validUntil: string
}