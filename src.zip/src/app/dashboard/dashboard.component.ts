import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import { DataSource } from '@angular/cdk/table';
import { Observable } from 'rxjs/Observable';

import { DataService } from '../data.service'
import { RestAPIService } from '../rest-api.service';
import { QRC_Record } from '../qrc-record';
import { QrcodeDialogComponent } from '../qrcode-dialog/qrcode-dialog.component';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})

export class DashboardComponent implements OnInit {

  constructor(private dataService: DataService, private api: RestAPIService, public dialog: MatDialog ) { }

  displayedColumns = ['displayName', 'shortName','callToAction', 'urlString', 'delete'];
  userRecords: QRC_Record[]; // = new QRCodeDataSource( this.dataService, this.api );

  recordCount : number;
  maxRecords = 5; // for beta purposes, we limit to 5 records per user
  userID : number;
  userIsLoggedIn = false;

  ngOnInit() {

    this.api.getUserID().subscribe( result => { 
      this.userID = result.id; 
      if ( this.userID != 0) 
        this.userIsLoggedIn = true;

      console.log("The user is loggedin? " + this.userIsLoggedIn);

      this.api.saveUserID( this.userID );
//      this.userRecords = new QRCodeDataSource( this.dataService, this.api );
      this.dataService.getUserRecords( this.userID )
        .subscribe( records => {

          this.userRecords = records;
          this.recordCount = this.userRecords.length;
          console.log("At startup we have " + this.recordCount + " records");

        });

    });

  }

  openDialog() : void {

    let dialogRef = this.dialog.open( QrcodeDialogComponent, 
      { width: '600px', data: 'Add QR Code'});

    dialogRef.componentInstance.event.subscribe( (result : QRC_Record) => {
    //
    // We should only get here if the data was vallidated.  Trust it
    //
    this.userRecords = this.dataService.addRecord( result );
    this.recordCount = this.userRecords.length;
    //    this.userRecords$ = new QRCodeDataSource( this.dataService, this.api );  // get the data again
    
    console.log("We now have " + this.recordCount + " records");

    });

  }

  deleteRecord( record: number ) {
  
    console.log("Got a call to delete a record : " + record );
    if (confirm("Are you sure you want to delete the record : " + this.dataService.getRecordById( record ).displayName + "? This cannot be reversed!!" )) 
      this.dataService.deleteRecord( record );    
  }
}

export class QRCodeDataSource extends DataSource<any> {

  constructor( private dataService: DataService, private api: RestAPIService ){
    super();
  }

  connect( ) : Observable<QRC_Record[]> {

    return this.dataService.getUserRecords( this.api.retrieveUserID() );

  }

  disconnect() {}

}