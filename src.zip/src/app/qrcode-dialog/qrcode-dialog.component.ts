import { Component, EventEmitter, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';

import { DataService } from '../data.service';
import { QRC_Record } from '../qrc-record';
import { RestAPIService } from '../rest-api.service';

@Component({
  selector: 'app-qrcode-dialog',
  templateUrl: './qrcode-dialog.component.html',
  styleUrls: ['./qrcode-dialog.component.scss']
})
export class QrcodeDialogComponent implements OnInit {

  constructor( 
    private api: RestAPIService,
    public dialogRef: MatDialogRef<QrcodeDialogComponent>,
    @Inject( MAT_DIALOG_DATA ) public data: any,
    public dataService: DataService
    ) { }

  alphanumericPattern = "'^[a-zA-Z0-9 \'\-\!]+$'";
  urlPattern = /(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;

  qrCodeData = {
    displayString: '',
    urlString: '',
    shortNameUsed: false,
    callToActionString: '',
    position: 0,
  };

  theForm: any;

  public event: EventEmitter<any> = new EventEmitter();

  onNoClick() : void {
    
    this.dialogRef.close();

  }

  resetForm() {
  
    if ( !!this.theForm )
    this.theForm.reset();

  }

  lifeOfEntry = 100; // in years....
  onSubmit( theForm ) : void {
    //
    // Once all the processing is done, the form will
    // need to be updated to reflect the change in records.  
    // Save the form information for later
    //
    this.theForm = theForm;

    this.qrCodeData.position = this.dataService.getDataLength();

    const newData = {} as QRC_Record;

    newData.id = 1;
    newData.displayName = this.qrCodeData.displayString;
    newData.callToActionString = this.qrCodeData.callToActionString;
    newData.urlString = this.qrCodeData.urlString;
    newData.userID = this.api.retrieveUserID();
    newData.backgroundName = "";
    newData.shortNameUsed = this.qrCodeData.shortNameUsed;
    newData.dateCreated = JSON.stringify( Date());

    let tempDate = new Date();
    newData.validUntil = JSON.stringify( new Date( tempDate.getFullYear() + this.lifeOfEntry, tempDate.getMonth(), tempDate.getDay() ) ) ;
//  deserialized = new Date(JSON.parse(serialized));

    this.event.emit( {data: newData} );

    this.dialogRef.close();

  }

  minNameLength = 1;
  maxNameLength = 30;
  validateName( name: string ) : boolean {

    name = name.trim();
    
    if ( name.match(this.alphanumericPattern) )
      return this.validateStringSize( name, this.minNameLength, this.maxNameLength );
    else
    return false;

  }

  minCallToActionLength = 1;
  maxCallToActionLength = 30;
  validateCallToAction( callToAction: string ) : boolean {
    
    callToAction = callToAction.trim();

    if ( callToAction.match(this.alphanumericPattern) ) 
      return this.validateStringSize( callToAction.trim(), this.minCallToActionLength, this.maxCallToActionLength );
    else
      return false;

  }

  validateURL( urlString: string ) : boolean  {

    let regexp = "(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?";
 //   return regexp.test(urlString);
    return this.urlPattern.test(urlString);

  }


  validateStringSize( str: string, minSize: number, maxSize: number ) : boolean {

    let stringLength = str.length;

    return (stringLength >= minSize) && (stringLength <= maxSize) ;

  }

  ngOnInit() {

  }

}
